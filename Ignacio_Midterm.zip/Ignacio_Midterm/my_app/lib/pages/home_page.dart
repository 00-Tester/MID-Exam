import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('All You Need To Know In Making A Spanish Latte',
        style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
        ),
      ),
        backgroundColor: Colors.brown,
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipOval(
              child: Image.network(
                'https://tse1.explicit.bing.net/th/id/OIP.rUYr8FsfIoAHbjNKVPLPNAHaHM?rs=1&pid=ImgDetMain&o=7&rm=3',
                width: 300,
                height: 300,
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(height: 20),
            RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: 'Ingredients For A Simple Spanish Latte:\n',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                      fontSize: 24,
                    ),
                  ),
                  TextSpan(
                    text: '1 cup strong espresso or strong coffee\n1/2 cup sweetened condensed milk\n1/2 cup steamed milk',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 20,
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
