import 'package:flutter/material.dart';

class AboutPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('About the coffee',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.brown,
        centerTitle: true,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text(
            'A Spanish latte is a deliciously sweet and creamy coffee drink that combines the bold flavor of espresso with the rich sweetness of condensed milk. Unlike a traditional latte that uses plain milk and sugar, the Spanish latte uses sweetened condensed milk to give it a distinctive smooth and caramel-like taste. It’s a perfect choice for those who want a coffee with a bit of extra indulgence.\n\nTo make a Spanish latte, start by brewing a strong cup of espresso or strong coffee. Next, pour about half a cup of sweetened condensed milk into your cup. Add the hot espresso to the condensed milk and stir well to combine the flavors evenly. Then, steam or heat half a cup of milk until it’s hot and frothy. Pour the steamed milk over the coffee and condensed milk mixture to create a creamy, velvety drink that’s both comforting and energizing.\n\nThis drink can also be enjoyed iced by simply pouring the coffee and condensed milk mixture over ice and adding cold milk instead of steamed. Whether served hot or cold, the Spanish latte offers a unique twist on traditional coffee drinks with its perfect balance of sweetness and strength. It’s a simple yet satisfying recipe that’s easy to make at home and perfect for any time of the day.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 16),

          ),
        ),
      ),
    );
  }
}
